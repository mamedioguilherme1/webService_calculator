<?php require'header.php'; ?>

<div align="center" style="margin-top: 9%;">
	
		<button class="btn"><a href="insertar.php">Insertar</a></button>
		<button class="btn btn-outline-primary"><a href="listar.php">Listar</a></button>
		<button  class="btn btn-outline-primary"><a href="eliminar.php">Eliminar</a></button>
		<button  class="btn btn-outline-primary"><a href="buscar.php">Buscar</a></button>
		<button class="btn btn-outline-primary"><a href="actualizar.php">Actualizar</a></button>	
</div>
<br>
<?php require 'footer.php'; ?>